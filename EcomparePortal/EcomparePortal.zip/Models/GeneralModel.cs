﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace EcomparePortal.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public string Icon { get; set; }
        public int Priority { get; set; }
    }
    public class SubCategory
    {
        [Key]
        public int Id { get; set; }
        public Category Category { get; set; }
        [ForeignKey("Category")]
        public int CategoryId { get; set; }

        public string SubCategoryName { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public string Icon { get; set; }
        public int Priority { get; set; }
    }
    
    public class Company
    {
        [Key]
        public int Id { get; set; }
        
        public string CompanyName { get; set; }

        public string CompanyEmail { get; set; }

        public string Logo { get; set; }
        public string Status { get; set; }

        public string Priority { get; set; }
        public string IsFeatured { get; set; }
    }
    public class Product
    {
        [Key]
        public int Id { get; set; }

        public string ProductName { get; set; }

        

        public string ProductPrice { get; set; }

        public string Logo { get; set; }

        public SubCategory SubCategory { get; set; }
        [ForeignKey("SubCategory")]
        public int SubCategoryId { get; set; }

        public Company Company { get; set; }
        [ForeignKey("Company")]
        public int CompanyId { get; set; }

        public string Status { get; set; }

        public string Priority { get; set; }
        public string IsFeatured { get; set; }
        public string Description { get; set; }

    }
    public class ProductImages
    {
        [Key]
        public int Id { get; set; }

        public string ImageURL { get; set; }
        

        public Product Product { get; set; }
        [ForeignKey("Product")]
        public int ProductId { get; set; }

    }
}