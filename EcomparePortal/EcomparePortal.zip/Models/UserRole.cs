﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EcomparePortal.Models
{
    public class UserRole
    {
        public static string Customer = "Customer";
        public static string Admin = "Admin";
    }
}