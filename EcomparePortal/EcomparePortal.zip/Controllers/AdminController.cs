﻿using EcomparePortal.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

namespace EcomparePortal.Controllers
{
    public class AdminController : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ListCategory()
        {

            var categorydata = db.Categories.FirstOrDefault();
            var categorydata1 = db.Categories.ToList().OrderBy(y=>y.Priority);

            if (categorydata == null)
            {
                return RedirectToAction("AddCategory");
            }
            else
            {
                return View(categorydata1);
            }
        }
        public ActionResult AddCategory()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddCategory(Category category, HttpPostedFileBase file)
        {
            string logo = Path.Combine(Server.MapPath("~/CategoryImages/"), file.FileName);
            file.SaveAs(logo);
            string path = "https://ecompareportal.webddocsystems.com/CategoryImages/" + file.FileName;
            category.Icon = path;

            db.Categories.Add(category);
            db.SaveChanges();

            return RedirectToAction("ListCategory");
        }
        public ActionResult EditCategory(string id)
        {
            var id1 = Int32.Parse(id);
            var list = db.Categories.Where(x => x.Id == id1).FirstOrDefault();
            ViewBag.categoryid = id;

            return View(list);
        }
        [HttpPost]
        public ActionResult EditCategory(FormCollection fc, Category category)
        {
            var id = fc["Id"];
            var id1 = Int32.Parse(id);
            var list = db.Categories.Where(x => x.Id == id1).FirstOrDefault();
            list.CategoryName = category.CategoryName;
            list.Description = category.Description;
            list.Status = category.Status;
            list.Priority = category.Priority;
            db.SaveChanges();
            return RedirectToAction("ListCategory");
        }
        public ActionResult DeleteCategory(string id)
        {
            var id1 = Int32.Parse(id);
            var categorydata = db.Categories.Where(x => x.Id == id1).FirstOrDefault();
            var subcategorydata = db.SubCategories.Where(x => x.CategoryId == id1).ToList();


            foreach (var item in subcategorydata)
            {
                db.SubCategories.Remove(item);
            }
            db.Categories.Remove(categorydata);
            db.SaveChanges();
            return RedirectToAction("ListCategory");
        }
        public ActionResult ListSubCategory(string id)
        {
            var id1 = Int32.Parse(id);
            var subcategorydata = db.SubCategories.Where(x => x.CategoryId == id1).Include(y=>y.Category).FirstOrDefault();
            if (subcategorydata != null)
            {

                ViewBag.subcategoryname = subcategorydata.Category.CategoryName;
            }
            var list = db.SubCategories.Where(x => x.CategoryId == id1).Include(y=>y.Category).ToList().OrderBy(y=>y.Priority);


            if (subcategorydata == null)
            {
                return RedirectToAction("AddSubCategory", new { id = id });
            }
            else
            {
                return View(list);
            }
        }
        public ActionResult AddSubCategory(string id)
        {
            ViewBag.categoryid = id;
            return View();
        }
        [HttpPost]
        public ActionResult AddSubCategory(SubCategory subcategory, HttpPostedFileBase file,FormCollection fc)
        {

            var id = fc["Id"];
            var id1 = Int32.Parse(id);
            string logo = Path.Combine(Server.MapPath("~/SubCategoryImages/"), file.FileName);
            file.SaveAs(logo);
            string path = "https://ecompareportal.webddocsystems.com/SubCategoryImages/" + file.FileName;
            subcategory.Icon = path;
            subcategory.CategoryId = id1;

            db.SubCategories.Add(subcategory);
            db.SaveChanges();

            return RedirectToAction("ListCategory");
        }
        public ActionResult EditSubCategory(string id)
        {
            var id1 = Int32.Parse(id);
            var list = db.SubCategories.Where(x => x.Id == id1).FirstOrDefault();
            ViewBag.subcategoryid = id;

            return View(list);
        }
        [HttpPost]
        public ActionResult EditSubCategory(FormCollection fc, SubCategory subcategory)
        {
            var id = fc["Id"];
            var id1 = Int32.Parse(id);
            var list = db.SubCategories.Where(x => x.Id == id1).FirstOrDefault();
            list.Priority = subcategory.Priority;
            list.Status = subcategory.Status;
            list.SubCategoryName = subcategory.SubCategoryName;
            list.Description = subcategory.Description;

            db.SaveChanges();
            return RedirectToAction("ListCategory");
        }
        public ActionResult DeleteSubCategory(string id)
        {
            //string path = Path.Combine(Server.MapPath("~/SubCategoryImages/"), file.FileName);
            //System.IO.File.Delete(path);
            var id1 = Int32.Parse(id);
            var data = db.SubCategories.Where(x => x.Id == id1).FirstOrDefault();
            db.SubCategories.Remove(data);
            db.SaveChanges();
            return RedirectToAction("ListCategory");
        }

        public ActionResult ListCompany()
        {

            var companydata = db.Companies.FirstOrDefault();
            var companydata1 = db.Companies.ToList();

            if (companydata == null)
            {
                return RedirectToAction("AddCompany");
            }
            else
            {
                return View(companydata1);
            }
        }
        public ActionResult AddCompany()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddCompany(Company company, HttpPostedFileBase file)
        {
            string logo = Path.Combine(Server.MapPath("~/CompanyImages/"), file.FileName);
            file.SaveAs(logo);
            string path = "https://ecompareportal.webddocsystems.com/CompanyImages/" + file.FileName;
            company.Logo = path;

            db.Companies.Add(company);
            db.SaveChanges();

            return RedirectToAction("ListCompany");
        }
        public ActionResult EditCompany(string id)
        {
            var id1 = Int32.Parse(id);
            var list = db.Companies.Where(x => x.Id == id1).FirstOrDefault();
            ViewBag.companyid = id;

            return View(list);
        }
        [HttpPost]
        public ActionResult EditCompany(FormCollection fc, Company company)
        {
            var id = fc["Id"];
            var id1 = Int32.Parse(id);
            var list = db.Companies.Where(x => x.Id == id1).FirstOrDefault();
            list.CompanyName = company.CompanyName;
            list.CompanyEmail = company.CompanyEmail;
            list.Status = company.Status;
            list.Priority = company.Priority;
            list.IsFeatured = company.IsFeatured;

            db.SaveChanges();
            return RedirectToAction("ListCompany");
        }

        public ActionResult DeleteCompany(string id)
        {
            var id1 = Int32.Parse(id);
            var companydata = db.Companies.Where(x => x.Id == id1).FirstOrDefault();
            
            db.Companies.Remove(companydata);
            db.SaveChanges();
            return RedirectToAction("ListCompany");
        }

        public ActionResult ListProduct()
        {
            
            var productdata = db.Products.FirstOrDefault();
            var list = db.Products.Include(y=>y.Company).Include(y=>y.SubCategory).ToList();


            if (productdata == null)
            {
                return RedirectToAction("AddProduct");
            }
            else
            {
                return View(list);
            }
        }
        public ActionResult AddProduct()
        {
            var list = db.Companies.ToList();
            ViewBag.CompanyId = new SelectList(list, "Id", "CompanyName");
            var list2 = db.SubCategories.ToList();
            ViewBag.SubCategoryId = new SelectList(list2, "Id", "SubCategoryName");

            return View();
        }
        [HttpPost]
        public ActionResult AddProduct(Product product, HttpPostedFileBase file, FormCollection fc)
        {

            
            string logo = Path.Combine(Server.MapPath("~/ProductImages/"), file.FileName);
            file.SaveAs(logo);
            string path = "https://ecompareportal.webddocsystems.com/ProductImages/" + file.FileName;
            product.Logo = path;

            var list = db.Companies.ToList();
            ViewBag.CompanyId = new SelectList(list, "Id", "CompanyName");
            var list2 = db.SubCategories.ToList();
            ViewBag.SubCategoryId = new SelectList(list2, "Id", "SubCategoryName");
            //product.SubCategoryId = id1;
            db.Products.Add(product);
            db.SaveChanges();

            return RedirectToAction("ListCategory");
        }

        public ActionResult EditProduct(string id)
        {
            var id1 = Int32.Parse(id);
            var list = db.Products.Where(x => x.Id == id1).FirstOrDefault();
            ViewBag.productid = id;

            return View(list);
        }
        [HttpPost]
        public ActionResult EditProduct(FormCollection fc, Product product)
        {
            var id = fc["Id"];
            var id1 = Int32.Parse(id);
            var list = db.Products.Where(x => x.Id == id1).FirstOrDefault();
            list.ProductName = product.ProductName;
            list.ProductPrice = product.ProductPrice;
            list.Status = product.Status;
            list.Priority = product.Priority;
            list.IsFeatured = product.IsFeatured;
            list.Description = product.Description;

            db.SaveChanges();
            return RedirectToAction("ListCategory");
        }
        public ActionResult DeleteProduct(string id)
        {
           
            var id1 = Int32.Parse(id);
            var data = db.Products.Where(x => x.Id == id1).FirstOrDefault();
            db.Products.Remove(data);
            db.SaveChanges();
            return RedirectToAction("ListCategory");
        }
        public ActionResult ListProductImages(string id)
        {
            var id1 = Int32.Parse(id);
            var productimagedata = db.ProductImages.Where(y=>y.ProductId==id1).FirstOrDefault();
            var list = db.ProductImages.Where(y=>y.ProductId==id1).ToList();


            if (productimagedata == null)
            {
                return RedirectToAction("UploadProductImages",new { id=id});
            }
            else
            {
                return View(list);
            }
        }
        public ActionResult UploadProductImages(string id)
        {
            ViewBag.productid = id;
            return View();
        }
        [HttpPost]
        public ActionResult UploadProductImages(ProductImages productimage, FormCollection fc,  IEnumerable<HttpPostedFileBase> Images)
        {
            var id = fc["Id"];
            var id1 = Int32.Parse(id);
            foreach (var image in Images)
            {

                string pathofimage = Path.Combine(Server.MapPath("~/ProductImages/" ), image.FileName);
                image.SaveAs(pathofimage);
                productimage.ImageURL = "https://ecompareportal.webddocsystems.com/ProductImages/" +  image.FileName;
                productimage.ProductId = id1;
                
                db.ProductImages.Add(productimage);
                db.SaveChanges();

            }


            return RedirectToAction("ListProduct");


        }

    }
}